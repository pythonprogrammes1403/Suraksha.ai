from fastapi import FastAPI
from pydantic import BaseModel

from .mcp import mcp_write, mcp_read

from .agents.intent_agent import run_intent_agent
from .agents.pattern_agent import run_pattern_agent
from .agents.risk_agent import run_risk_agent
from .agents.explanation_agent import run_explanation_agent
from .agents.alerts import trigger_alert

import logging

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI()
@app.get("/health")
def health_check():
    """Health check endpoint"""
    return {"status": "healthy", "service": "Suraksha.AI Fraud Detection"}


# Vendor profiles (demo defaults)
VENDOR_PROFILES = {
    "generic_vendor": {
        "vendor_id": "V000",
        "name": "Generic Vendor",
        "avg_amount": 500
    },
    "coffee_vendor": {
        "vendor_id": "V001",
        "name": "Coffee Vendor",
        "avg_amount": 200
    },
    "phone_repair": {
        "vendor_id": "V002",
        "name": "Phone Repair",
        "avg_amount": 2000
    }
}

class Transaction(BaseModel):
    amount: int
    message: str
    vendor_type: str = "generic_vendor"  # Default to generic vendor
    enable_voice_alert: bool = False  # Optional voice alerts
    sender_id: str | None = None
    sender_type: str = "unknown"  # unknown | official | known_contact
    channel: str = "unknown"  # sms | whatsapp | email | app | upi | other

@app.post("/analyze")
def analyze_transaction(tx: Transaction):
    transaction = tx.dict()
    logger.info(f"Analyzing transaction: {transaction['amount']} from {transaction['vendor_type']}")
    vendor_profile = VENDOR_PROFILES.get(transaction["vendor_type"], VENDOR_PROFILES["generic_vendor"])

    # STEP 1: Store transaction in MCP
    mcp_write("transaction", transaction)
    mcp_write("vendor", vendor_profile)

    # STEP 2: Intent Agent
    intent_result = run_intent_agent(transaction)
    mcp_write("intent_agent", intent_result)
    logger.info(f"Intent: {intent_result['intent']} (confidence: {intent_result['confidence']})")

    # STEP 3: Pattern Agent
    pattern_result = run_pattern_agent(transaction, vendor_profile)
    mcp_write("pattern_agent", pattern_result)
    logger.info(f"Pattern anomaly: {pattern_result['anomaly']}")

    # STEP 4: Risk Agent
    risk_result = run_risk_agent(intent_result, pattern_result)
    mcp_write("risk_agent", risk_result)
    logger.info(f"Risk score: {risk_result['risk_score']}, Decision: {risk_result['decision']}")

    # STEP 5: Explanation Agent
    explanation = run_explanation_agent(
        transaction,
        intent_result,
        pattern_result,
        risk_result
    )

    mcp_write("explanation", explanation)
    
    # STEP 6: Trigger Alert
    if transaction["enable_voice_alert"]:
        try:
            alert_message = trigger_alert(explanation, risk_result["decision"], risk_result["risk_score"], enable_voice=True)
            logger.info(f"Voice alert triggered: {alert_message}")
        except Exception as e:
            logger.error(f"Alert failed: {e}")
            alert_message = None
    else:
        alert_message = None

    return {
        "decision": risk_result["decision"],
        "risk_score": risk_result["risk_score"],
        "explanation": explanation,
        "scam_types": intent_result.get("scam_type", []),
        "alert_message": alert_message,
        "vendor_profile": vendor_profile
    }
