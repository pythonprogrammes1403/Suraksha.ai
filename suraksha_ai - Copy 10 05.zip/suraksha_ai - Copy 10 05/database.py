import sqlite3

conn = sqlite3.connect("mcp.db", check_same_thread=False)
cursor = conn.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS mcp_context (
    key TEXT PRIMARY KEY,
    value TEXT
)
""")

conn.commit()

def write_context(key, value):
    cursor.execute(
        "REPLACE INTO mcp_context (key, value) VALUES (?, ?)",
        (key, value)
    )
    conn.commit()

def read_context(key):
    cursor.execute(
        "SELECT value FROM mcp_context WHERE key = ?",
        (key,)
    )
    row = cursor.fetchone()
    return row[0] if row else None
