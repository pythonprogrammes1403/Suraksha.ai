import json
from .database import write_context, read_context

def mcp_write(key, data):
    write_context(key, json.dumps(data))

def mcp_read(key):
    data = read_context(key)
    return json.loads(data) if data else None
