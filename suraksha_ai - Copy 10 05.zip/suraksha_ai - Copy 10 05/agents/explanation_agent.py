def run_explanation_agent(transaction, intent, pattern, risk):
    if intent["intent"] == "verification" and risk["decision"] != "HIGH_RISK":
        return (
            "This looks like a legitimate verification request from a trusted source. "
            "No risky behavior detected."
        )

    if risk["decision"] == "HIGH_RISK":
        return (
            f"This transaction looks risky because the amount ₹{transaction['amount']} "
            f"is unusual for your business and the message indicates a possible {intent['intent']}."
        )

    return "This transaction appears normal based on your usual activity."
