def run_pattern_agent(transaction, vendor):
    amount = transaction["amount"]
    avg = vendor["avg_amount"]
    
    anomaly = False
    reasons = []
    anomaly_score = 0
    
    # Check if amount is significantly higher (5x threshold)
    if amount > avg * 5:
        anomaly = True
        reasons.append("Amount much higher than usual vendor sales")
        anomaly_score += 0.8
    
    # Check if amount is unusually high (2x threshold)
    elif amount > avg * 2:
        reasons.append("Amount higher than typical transactions")
        anomaly_score += 0.4
    
    # Check if amount is too low (less than 10% of average)
    elif amount > 0 and amount < avg * 0.1:
        reasons.append("Unusually low transaction amount")
        anomaly_score += 0.2
    
    return {
        "anomaly": anomaly,
        "anomaly_score": anomaly_score,
        "reason": " | ".join(reasons) if reasons else "Amount within normal range"
    }
