def run_intent_agent(transaction):
    msg = transaction["message"].lower()
    sender_type = transaction.get("sender_type", "unknown")
    channel = transaction.get("channel", "unknown")
    
    # Scam keywords organized by type
    refund_keywords = ["refund", "return", "reverse", "chargeback", "money back"]
    kyc_keywords = ["kyc", "verification", "identity", "aadhar", "pan", "account update"]
    urgent_keywords = ["urgent", "immediate", "asap", "hurry", "send now", "rush", "quick"]
    payment_keywords = ["collect", "payment", "charge", "deduct"]
    
    scam_indicators = []
    confidence = 0.1
    
    # Check for scam patterns
    if any(keyword in msg for keyword in refund_keywords):
        scam_indicators.append("refund")
        confidence = 0.9
    
    kyc_detected = any(keyword in msg for keyword in kyc_keywords)
    if kyc_detected:
        # Treat KYC as legit only when sender is trusted and channel looks official
        is_trusted_sender = sender_type in {"official", "known_contact"}
        is_trusted_channel = channel in {"app", "upi", "email"}
        if is_trusted_sender and is_trusted_channel:
            return {
                "intent": "verification",
                "confidence": 0.6,
                "scam_type": []
            }
        scam_indicators.append("kyc_phishing")
        confidence = 0.9
    
    if any(keyword in msg for keyword in urgent_keywords):
        scam_indicators.append("pressure_scam")
        confidence = 0.85
    
    if scam_indicators:
        return {
            "intent": "scam",
            "confidence": confidence,
            "scam_type": scam_indicators
        }
    
    # Legitimate payment intents
    if any(keyword in msg for keyword in payment_keywords):
        return {
            "intent": "payment",
            "confidence": 0.95,
            "scam_type": []
        }

    return {
        "intent": "normal",
        "confidence": 0.1,
        "scam_type": []
    }
