import pyttsx3
from typing import Optional

class AlertSystem:
    def __init__(self, language: str = "en"):
        self.engine = pyttsx3.init()
        self.language = language
        self.engine.setProperty('rate', 150)  # Speaking rate
        self.engine.setProperty('volume', 0.9)  # Volume level
    
    def voice_alert(self, message: str, urgency: str = "normal"):
        """Send a voice alert"""
        if urgency == "HIGH_RISK":
            # High-risk alerts are faster and louder
            self.engine.setProperty('rate', 200)
        else:
            self.engine.setProperty('rate', 150)
        
        self.engine.say(message)
        self.engine.runAndWait()
    
    def get_alert_message(self, explanation: str, decision: str, risk_score: float) -> str:
        """Generate appropriate alert message"""
        if decision == "HIGH_RISK":
            return f"ALERT! {explanation}. Risk score: {risk_score}"
        else:
            return f"Transaction appears safe. {explanation}"

# Initialize default alert system
alert_system = AlertSystem()

def trigger_alert(explanation: str, decision: str, risk_score: float, enable_voice: bool = True):
    """Trigger alert with optional voice"""
    message = alert_system.get_alert_message(explanation, decision, risk_score)
    
    if enable_voice:
        try:
            alert_system.voice_alert(message, decision)
        except Exception as e:
            print(f"Voice alert failed: {e}")
            print(f"Text alert: {message}")
    
    return message
