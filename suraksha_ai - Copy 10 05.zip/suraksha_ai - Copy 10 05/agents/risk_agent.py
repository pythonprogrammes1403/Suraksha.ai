def run_risk_agent(intent_result, pattern_result):
    score = 0
    anomaly_score = pattern_result.get("anomaly_score", 0)

    if intent_result["intent"] == "scam":
        score = max(score, 0.7)

    if anomaly_score:
        score = max(score, anomaly_score)

    # If both scam intent and meaningful anomaly are present, boost risk
    if intent_result["intent"] == "scam" and anomaly_score >= 0.4:
        score = max(score, 0.9)

    decision = "HIGH_RISK" if score >= 0.7 else "SAFE"

    return {
        "risk_score": score,
        "decision": decision
    }
